#!/bin/bash
echo "Starting Laam Wallet..."
source venv/bin/activate
python src/main.py
