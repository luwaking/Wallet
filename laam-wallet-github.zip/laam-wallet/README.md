# Laam Wallet

A modern, secure cryptocurrency wallet built on Stellar blockchain technology, specifically designed for managing Laam tokens and other Stellar-based assets.

## Features

- **Multi-Asset Support**: Manage LAAM, XLM, BTC, ETH and other cryptocurrencies
- **Real-time Portfolio Tracking**: Live balance updates and USD value conversion
- **Transaction History**: View recent send/receive transactions
- **Responsive Design**: Works seamlessly on desktop and mobile devices
- **Secure Architecture**: Built with Flask backend and modern web technologies

## Technology Stack

- **Frontend**: HTML5, CSS3, JavaScript (Vanilla)
- **Backend**: Python Flask with RESTful API
- **Database**: SQLite (for user management)
- **Styling**: Custom CSS with gradient backgrounds and modern UI
- **CORS**: Enabled for cross-origin requests

## Quick Start

### Prerequisites

- Python 3.11+
- pip (Python package manager)

### Installation

1. Clone this repository:
```bash
git clone <your-repo-url>
cd laam-wallet
```

2. Create and activate virtual environment:
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

3. Install dependencies:
```bash
pip install -r requirements.txt
```

4. Run the application:
```bash
python src/main.py
```

5. Open your browser and navigate to:
```
http://localhost:5000
```

## API Endpoints

### Wallet Endpoints

- `GET /api/assets` - Get all wallet assets
- `GET /api/transactions` - Get recent transactions
- `GET /api/balance` - Get total portfolio balance
- `POST /api/send` - Send assets (mock implementation)
- `POST /api/receive` - Generate receive address (mock)
- `POST /api/swap` - Swap assets (mock)
- `GET /api/asset/<symbol>` - Get specific asset details

### User Management Endpoints

- `GET /api/users` - Get all users
- `POST /api/users` - Create new user
- `GET /api/users/<id>` - Get specific user
- `PUT /api/users/<id>` - Update user
- `DELETE /api/users/<id>` - Delete user

## Project Structure

```
laam-wallet/
├── src/
│   ├── static/
│   │   └── index.html          # Main frontend application
│   ├── routes/
│   │   ├── user.py            # User management routes
│   │   └── wallet.py          # Wallet API routes
│   ├── models/
│   │   └── user.py            # User database model
│   ├── database/
│   │   └── app.db             # SQLite database
│   └── main.py                # Flask application entry point
├── venv/                      # Virtual environment
├── requirements.txt           # Python dependencies
└── README.md                  # This file
```

## Features Overview

### Dashboard
- Total portfolio value display
- Real-time balance updates
- Clean, modern interface

### Asset Management
- View all cryptocurrency holdings
- Individual asset balances and USD values
- Asset-specific icons and branding

### Transaction History
- Recent transaction display
- Send/receive transaction types
- Timestamp and amount information

### Action Buttons
- Send assets functionality
- Receive address generation
- Asset swap capabilities

## Mock Data

The application currently uses mock data for demonstration purposes:

- **Assets**: LAAM (1,335.577), XLM (5,000), BTC (0.05), ETH (0.8)
- **Transactions**: Sample send/receive transactions
- **Prices**: Simulated price variations (±5% random changes)

## Deployment

### Local Development
```bash
python src/main.py
```

### Production Deployment
For production deployment, consider using:
- Gunicorn or uWSGI as WSGI server
- Nginx as reverse proxy
- Environment variables for configuration
- PostgreSQL or MySQL for production database

## Security Features

- CORS enabled for cross-origin requests
- SQLite database with proper models
- Input validation on API endpoints
- Secure session management

## Browser Compatibility

- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

This project is open source and available under the MIT License.

## Support

For support and questions, please open an issue in the GitHub repository.

---

**Powered by Laam Network** 🔒 *Your assets are secured with Stellar blockchain technology*

