from flask import Blueprint, jsonify, request
from datetime import datetime, timedelta
import random

wallet_bp = Blueprint('wallet', __name__)

# Mock data for demonstration
MOCK_ASSETS = [
    {
        'name': 'Laam',
        'symbol': 'LAAM',
        'balance': 1335.577,
        'usdValue': 2671.15,
        'icon': '💰'
    },
    {
        'name': 'Stellar',
        'symbol': 'XLM',
        'balance': 5000.0,
        'usdValue': 2100.00,
        'icon': '✦'
    },
    {
        'name': 'Bitcoin',
        'symbol': 'BTC',
        'balance': 0.05,
        'usdValue': 1375.00,
        'icon': '₿'
    },
    {
        'name': 'Ethereum',
        'symbol': 'ETH',
        'balance': 0.8,
        'usdValue': 2144.00,
        'icon': 'Ξ'
    }
]

MOCK_TRANSACTIONS = [
    {
        'id': 1,
        'type': 'receive',
        'asset': 'LAAM',
        'amount': 100.0,
        'timestamp': (datetime.now() - timedelta(hours=2)).isoformat(),
        'hash': 'abc123def456'
    },
    {
        'id': 2,
        'type': 'send',
        'asset': 'XLM',
        'amount': 500.0,
        'timestamp': (datetime.now() - timedelta(days=1)).isoformat(),
        'hash': 'def456ghi789'
    },
    {
        'id': 3,
        'type': 'receive',
        'asset': 'BTC',
        'amount': 0.01,
        'timestamp': (datetime.now() - timedelta(days=2)).isoformat(),
        'hash': 'ghi789jkl012'
    },
    {
        'id': 4,
        'type': 'send',
        'asset': 'ETH',
        'amount': 0.2,
        'timestamp': (datetime.now() - timedelta(days=3)).isoformat(),
        'hash': 'jkl012mno345'
    },
    {
        'id': 5,
        'type': 'receive',
        'asset': 'LAAM',
        'amount': 235.577,
        'timestamp': (datetime.now() - timedelta(days=5)).isoformat(),
        'hash': 'mno345pqr678'
    }
]

@wallet_bp.route('/assets', methods=['GET'])
def get_assets():
    """Get all wallet assets"""
    try:
        # Add some random variation to simulate live prices
        assets = []
        for asset in MOCK_ASSETS:
            asset_copy = asset.copy()
            # Add ±5% random variation to USD value
            variation = random.uniform(-0.05, 0.05)
            asset_copy['usdValue'] = round(asset['usdValue'] * (1 + variation), 2)
            assets.append(asset_copy)
        
        return jsonify(assets), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@wallet_bp.route('/transactions', methods=['GET'])
def get_transactions():
    """Get recent transactions"""
    try:
        # Sort transactions by timestamp (newest first)
        sorted_transactions = sorted(MOCK_TRANSACTIONS, 
                                   key=lambda x: x['timestamp'], 
                                   reverse=True)
        return jsonify(sorted_transactions), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@wallet_bp.route('/balance', methods=['GET'])
def get_total_balance():
    """Get total portfolio balance"""
    try:
        total_usd = sum(asset['usdValue'] for asset in MOCK_ASSETS)
        # Add some random variation
        variation = random.uniform(-0.02, 0.02)
        total_usd = round(total_usd * (1 + variation), 2)
        
        return jsonify({
            'totalUSD': total_usd,
            'currency': 'USD',
            'lastUpdated': datetime.now().isoformat()
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@wallet_bp.route('/send', methods=['POST'])
def send_assets():
    """Send assets (mock implementation)"""
    try:
        data = request.get_json()
        
        # Create a mock transaction
        new_transaction = {
            'id': len(MOCK_TRANSACTIONS) + 1,
            'type': 'send',
            'asset': data.get('asset', 'LAAM'),
            'amount': data.get('amount', 10.0),
            'timestamp': datetime.now().isoformat(),
            'hash': f"send_{random.randint(100000, 999999)}"
        }
        
        MOCK_TRANSACTIONS.insert(0, new_transaction)
        
        return jsonify({
            'success': True,
            'message': 'Transaction initiated',
            'transaction': new_transaction
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@wallet_bp.route('/receive', methods=['POST'])
def receive_assets():
    """Generate receive address (mock implementation)"""
    try:
        # Generate a mock Stellar address
        mock_address = f"GAAM{random.randint(100000000000000000000000000000000000000000000000, 999999999999999999999999999999999999999999999999)}"
        
        return jsonify({
            'success': True,
            'address': mock_address,
            'qrCode': f"stellar:{mock_address}",
            'message': 'Receive address generated'
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@wallet_bp.route('/swap', methods=['POST'])
def swap_assets():
    """Swap assets (mock implementation)"""
    try:
        data = request.get_json()
        
        # Create a mock swap transaction
        new_transaction = {
            'id': len(MOCK_TRANSACTIONS) + 1,
            'type': 'swap',
            'asset': f"{data.get('fromAsset', 'XLM')} → {data.get('toAsset', 'LAAM')}",
            'amount': data.get('amount', 100.0),
            'timestamp': datetime.now().isoformat(),
            'hash': f"swap_{random.randint(100000, 999999)}"
        }
        
        MOCK_TRANSACTIONS.insert(0, new_transaction)
        
        return jsonify({
            'success': True,
            'message': 'Swap completed',
            'transaction': new_transaction
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@wallet_bp.route('/asset/<symbol>', methods=['GET'])
def get_asset_details(symbol):
    """Get details for a specific asset"""
    try:
        asset = next((a for a in MOCK_ASSETS if a['symbol'] == symbol.upper()), None)
        if not asset:
            return jsonify({'error': 'Asset not found'}), 404
        
        # Add some additional details
        asset_details = asset.copy()
        asset_details.update({
            'price': round(asset['usdValue'] / asset['balance'], 6),
            'change24h': round(random.uniform(-10, 10), 2),
            'marketCap': round(asset['usdValue'] * random.randint(1000, 10000), 2)
        })
        
        return jsonify(asset_details), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

